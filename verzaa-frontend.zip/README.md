# Verzaa Frontend

This is the frontend for Verzaa e-commerce app.